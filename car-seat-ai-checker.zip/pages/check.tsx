import { useState } from 'react';
import { useRouter } from 'next/router';

export default function Check() {
  const router = useRouter();
  const [file, setFile] = useState<File | null>(null);
  const [age, setAge] = useState('');
  const [weight, setWeight] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError('');

    if (!file || !age || !weight || isNaN(Number(age)) || isNaN(Number(weight))) {
      setError('Please upload a photo and enter valid age and weight.');
      return;
    }

    const form = new FormData();
    form.append('photo', file);
    form.append('childAge', age);
    form.append('childWeight', weight);

    try {
      setLoading(true);
      const res = await fetch('/api/analyze', { method: 'POST', body: form });
      const data = await res.json();
      router.push({
        pathname: '/results',
        query: { feedback: JSON.stringify(data.feedback) },
      });
    } catch (err) {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Upload Your Car Seat</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label>
            Photo:
            <input type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0] || null)} />
          </label>
        </div>
        <div>
          <label>
            Child Age (years):
            <input type="number" value={age} onChange={(e) => setAge(e.target.value)} min="0" required />
          </label>
        </div>
        <div>
          <label>
            Child Weight (lbs):
            <input type="number" value={weight} onChange={(e) => setWeight(e.target.value)} min="0" required />
          </label>
        </div>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <button type="submit" disabled={loading}>
          {loading ? 'Analyzing...' : 'Submit'}
        </button>
      </form>
    </div>
  );
}
