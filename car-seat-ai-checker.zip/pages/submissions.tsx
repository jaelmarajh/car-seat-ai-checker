import useSWR from 'swr';

const fetcher = (url: string) => fetch(url).then(res => res.json());

export default function Submissions() {
  const { data, error, isLoading } = useSWR('/api/submissions', fetcher);

  if (isLoading) return <p>Loading...</p>;
  if (error) return <p>Failed to load submissions.</p>;

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>All Submissions</h1>
      <ul>
        {data?.items?.map((s: any, i: number) => (
          <li key={i}>{s.date} – {s.childAge}y, {s.childWeight}lbs</li>
        ))}
      </ul>
    </div>
  );
}
